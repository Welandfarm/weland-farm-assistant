import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import {
  ChevronRight,
  MessageSquare,
  Leaf,
  CloudSun,
  FlaskRoundIcon as Flask,
  BarChart,
  Users,
  Phone,
  Mail,
  MapPin,
  ArrowRight,
  Check,
  CalendarIcon,
} from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <header className="sticky top-0 z-40 w-full border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-green-600" />
            <span className="text-xl font-bold">Weland Farm Assistant</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#about" className="text-sm font-medium hover:text-green-600 transition-colors">
              About
            </a>
            <a href="#how-it-works" className="text-sm font-medium hover:text-green-600 transition-colors">
              How It Works
            </a>
            <a href="#services" className="text-sm font-medium hover:text-green-600 transition-colors">
              Services
            </a>
            <a href="#blog" className="text-sm font-medium hover:text-green-600 transition-colors">
              Blog
            </a>
            <a href="#success-stories" className="text-sm font-medium hover:text-green-600 transition-colors">
              Success Stories
            </a>
            <a href="#contact" className="text-sm font-medium hover:text-green-600 transition-colors">
              Contact
            </a>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" className="hidden md:flex">
              Log In
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">Get Started</Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 md:py-28 bg-gradient-to-r from-orange-50 via-green-50 to-blue-50 overflow-hidden">
          <div className="container flex flex-col md:flex-row items-center gap-8 md:gap-16">
            <div className="flex-1 space-y-6 text-center md:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
                Healthy Soil, <br />
                <span className="text-green-600">Higher Yields</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-600 max-w-xl">
                Site-specific, crop-specific soil fertility recommendations using AI, weather data, and localized soil
                reports.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button className="bg-orange-500 hover:bg-orange-600 h-12 px-6 text-base">
                  Get Recommendations
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" className="h-12 px-6 text-base">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="flex-1 relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Farmer using Weland Farm Assistant"
                width={600}
                height={500}
                className="rounded-lg shadow-xl"
                priority
              />
            </div>
          </div>
          <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-orange-200 rounded-full opacity-50 blur-3xl"></div>
          <div className="absolute top-16 -right-16 w-64 h-64 bg-green-200 rounded-full opacity-50 blur-3xl"></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-blue-200 rounded-full opacity-40 blur-3xl"></div>
          <div className="absolute bottom-1/3 right-1/4 w-32 h-32 bg-purple-200 rounded-full opacity-30 blur-3xl"></div>
        </section>

        {/* About Us Section */}
        <section id="about" className="py-16 md:py-24 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">About Weland Farm Assistant</h2>
              <p className="text-lg text-gray-600">
                Founded in 2017 to empower Kenyan farmers with data-driven insights, Weland Farm Assistant combines
                agricultural expertise with cutting-edge technology to boost productivity and sustainability.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Leaf className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
                  <p className="text-gray-600">
                    To transform agriculture in Kenya through accessible, data-driven soil management solutions.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CloudSun className="h-6 w-6 text-orange-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Our Approach</h3>
                  <p className="text-gray-600">
                    Combining local knowledge with AI and weather data to provide tailored recommendations.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Our Impact</h3>
                  <p className="text-gray-600">
                    Helping thousands of farmers increase yields while practicing sustainable agriculture.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="py-16 md:py-24 bg-gradient-to-r from-orange-50 to-yellow-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">How It Works</h2>
              <p className="text-lg text-gray-600">
                Our platform makes it easy to get personalized soil recommendations in just a few simple steps.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
              <div className="hidden md:block absolute top-1/2 left-1/3 right-1/3 h-0.5 bg-green-200 -z-10"></div>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-orange-500 text-white rounded-full flex items-center justify-center text-xl font-bold mb-6">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-2">Input Your Details</h3>
                <p className="text-gray-600">
                  Enter your location, crop type, and current season through our simple interface.
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-xl font-bold mb-6">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-2">AI Analysis</h3>
                <p className="text-gray-600">
                  Our system processes your data along with soil maps, weather patterns, and crop requirements, also
                  referring to available soil data on soil fertility and suitability analysis.
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-blue-500 text-white rounded-full flex items-center justify-center text-xl font-bold mb-6">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-2">Get Recommendations</h3>
                <p className="text-gray-600">
                  Receive tailored fertilizer recommendations and soil management practices for optimal yields.
                </p>
              </div>
            </div>
            <div className="mt-16 text-center">
              <Button className="bg-orange-500 hover:bg-orange-600">
                Try It Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* Our Services Section */}
        <section id="services" className="py-16 md:py-24 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Services</h2>
              <p className="text-lg text-gray-600">
                Comprehensive solutions to improve your farm's productivity and sustainability.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex-shrink-0 flex items-center justify-center">
                  <Flask className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Soil Testing</h3>
                  <p className="text-gray-600">
                    Comprehensive soil analysis to understand nutrient levels, pH, and organic matter content for
                    informed decision-making.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-brown-100 rounded-full flex-shrink-0 flex items-center justify-center bg-amber-100">
                  <BarChart className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Fertility Management Plans</h3>
                  <p className="text-gray-600">
                    Customized fertilizer recommendations based on your specific soil conditions and crop requirements.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex-shrink-0 flex items-center justify-center">
                  <CloudSun className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Sustainable Land Use</h3>
                  <p className="text-gray-600">
                    Guidance on crop rotation, cover crops, and conservation practices to maintain soil health
                    long-term.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex-shrink-0 flex items-center justify-center">
                  <Users className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Agronomy Support</h3>
                  <p className="text-gray-600">
                    Expert advice from agricultural specialists to help implement recommendations and troubleshoot
                    issues.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <div className="w-12 h-12 bg-green-100 rounded-full flex-shrink-0 flex items-center justify-center">
                  <BarChart className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Farm Management Services</h3>
                  <p className="text-gray-600">
                    We manage your investment from land preparation to harvest, guaranteeing you higher yields, without
                    the headaches and time-consuming challenges of regular visits to manage farm operations.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Video Showcase Section */}
        <section className="py-16 md:py-24 bg-gradient-to-r from-purple-50 to-orange-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">See Our Impact</h2>
              <p className="text-lg text-gray-600">
                Watch how Weland Farm Assistant is transforming agriculture across Kenya.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="rounded-xl overflow-hidden shadow-lg bg-white p-4">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden mb-4 flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=300&width=500"
                    alt="Video thumbnail"
                    width={500}
                    height={300}
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-8 w-8 text-white"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                      >
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">Transforming Maize Farming in Bomet</h3>
                <p className="text-gray-600">
                  See how our soil analysis and recommendations helped farmers increase their yields by up to 40%.
                </p>
              </div>
              <div className="rounded-xl overflow-hidden shadow-lg bg-white p-4">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden mb-4 flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=300&width=500"
                    alt="Video thumbnail"
                    width={500}
                    height={300}
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-8 w-8 text-white"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                      >
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">How Weland Chat Works</h3>
                <p className="text-gray-600">
                  A quick demonstration of how our AI-powered chat assistant provides real-time farming advice.
                </p>
              </div>
            </div>
            <div className="mt-12 text-center">
              <Button className="bg-orange-500 hover:bg-orange-600">
                Watch More Videos
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* AI Chat Assistant Section */}
        <section className="py-16 md:py-24 bg-gradient-to-r from-orange-50 via-yellow-50 to-green-50">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Weland Chat</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Get instant answers to your farming questions with our AI-powered chat assistant. Available 24/7 to
                  provide guidance on soil management, crop selection, and best practices.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-600" />
                    <span>Ask about specific crop requirements</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-600" />
                    <span>Get fertilizer application advice</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-600" />
                    <span>Troubleshoot common soil issues</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-600" />
                    <span>Learn about sustainable farming practices</span>
                  </li>
                </ul>
                <Button className="bg-orange-500 hover:bg-orange-600">
                  Try Weland Chat
                  <MessageSquare className="ml-2 h-4 w-4" />
                </Button>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="bg-gray-100 rounded-lg p-4 mb-4">
                  <p className="text-sm font-medium">AI Assistant</p>
                  <p className="text-gray-700">
                    Hello! I'm your Weland Farm Assistant. How can I help with your farming needs today?
                  </p>
                </div>
                <div className="bg-green-100 rounded-lg p-4 mb-4 ml-8">
                  <p className="text-sm font-medium">You</p>
                  <p className="text-gray-700">What fertilizer should I use for maize in Bomet County?</p>
                </div>
                <div className="bg-gray-100 rounded-lg p-4">
                  <p className="text-sm font-medium">AI Assistant</p>
                  <p className="text-gray-700">
                    For maize in Bomet County, I recommend using NPK 17:17:17 at planting, followed by CAN top-dressing
                    when the maize is knee-high. Bomet soils are typically acidic, so consider adding lime if your soil
                    pH is below 5.5. Would you like more specific recommendations based on your exact location?
                  </p>
                </div>
                <div className="mt-4 flex gap-2">
                  <Input placeholder="Ask a question..." className="flex-1" />
                  <Button size="icon" className="bg-green-600 hover:bg-green-700">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Section */}
        <section id="blog" className="py-16 md:py-24 bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Blog</h2>
              <p className="text-lg text-gray-600">
                Stay updated with the latest farming insights, soil management techniques, and success stories.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog post thumbnail"
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <CalendarIcon className="h-4 w-4" />
                    <span>April 10, 2025</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Maximizing Maize Yields in Kenyan Highlands</h3>
                  <p className="text-gray-600 mb-4">
                    Learn the best practices for maize cultivation in Kenya's highland regions, including soil
                    preparation, seed selection, and fertilizer application.
                  </p>
                  <Button variant="link" className="p-0 h-auto text-orange-500 hover:text-orange-600">
                    Read More <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-none shadow-md hover:shadow-lg transition-shadow overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog post thumbnail"
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <CalendarIcon className="h-4 w-4" />
                    <span>April 5, 2025</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Understanding Soil pH and Its Impact on Crop Health</h3>
                  <p className="text-gray-600 mb-4">
                    Discover how soil pH affects nutrient availability and what measures you can take to optimize your
                    soil's pH levels for better crop performance.
                  </p>
                  <Button variant="link" className="p-0 h-auto text-orange-500 hover:text-orange-600">
                    Read More <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-none shadow-md hover:shadow-lg transition-shadow overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog post thumbnail"
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <CalendarIcon className="h-4 w-4" />
                    <span>March 28, 2025</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Sustainable Farming Practices for Small-Scale Farmers</h3>
                  <p className="text-gray-600 mb-4">
                    Explore cost-effective and environmentally friendly farming techniques that can help small-scale
                    farmers improve yields while preserving soil health.
                  </p>
                  <Button variant="link" className="p-0 h-auto text-orange-500 hover:text-orange-600">
                    Read More <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            </div>
            <div className="mt-12 text-center">
              <Button variant="outline" className="border-orange-500 text-orange-500 hover:bg-orange-50">
                View All Articles
              </Button>
            </div>
          </div>
        </section>

        {/* Success Stories Section */}
        <section id="success-stories" className="py-16 md:py-24 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Success Stories</h2>
              <p className="text-lg text-gray-600">
                See how farmers across Kenya are transforming their yields with Weland Farm Assistant.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">James Kiprop</h3>
                      <p className="text-sm text-gray-500">Bomet County</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "After using Weland's recommendations, my maize yield increased by 40% compared to last season. The
                    soil-specific advice made all the difference."
                  </p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Sarah Wanjiku</h3>
                      <p className="text-sm text-gray-500">Nakuru County</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "The AI assistant helped me identify a nutrient deficiency in my soil that was affecting my potato
                    crop. Following their advice, I've seen healthier plants and better harvests."
                  </p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Daniel Ochieng</h3>
                      <p className="text-sm text-gray-500">Kisumu County</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "As a small-scale farmer, I couldn't afford costly mistakes. Weland's affordable soil testing and
                    precise recommendations have helped me maximize my limited resources."
                  </p>
                </CardContent>
              </Card>
            </div>
            <div className="mt-12 text-center">
              <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                Read More Success Stories
              </Button>
            </div>
          </div>
        </section>

        {/* Get Started Section */}
        <section id="get-started" className="py-16 md:py-24 bg-orange-500 text-white">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Farm?</h2>
                <p className="text-lg mb-8">
                  Book a consultation with our team of agricultural experts and start your journey toward smarter
                  farming and better harvests.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5" />
                    <span>Personalized soil analysis</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5" />
                    <span>Custom fertilizer recommendations</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5" />
                    <span>Ongoing support from agronomists</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-5 w-5" />
                    <span>Access to our AI assistant</span>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-lg text-gray-900">
                <h3 className="text-2xl font-bold mb-6 text-center">Book a Consultation</h3>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="first-name" className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <Input id="first-name" placeholder="John" />
                    </div>
                    <div>
                      <label htmlFor="last-name" className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <Input id="last-name" placeholder="Doe" />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="john@example.com" />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone
                    </label>
                    <Input id="phone" placeholder="+254 7XX XXX XXX" />
                  </div>
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                      County/Location
                    </label>
                    <Input id="location" placeholder="Bomet County" />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Tell us about your farm
                    </label>
                    <Textarea
                      id="message"
                      placeholder="Crop types, farm size, challenges you're facing..."
                      className="min-h-[100px]"
                    />
                  </div>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">Book a Consultation</Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Us Section */}
        <section id="contact" className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Contact Us</h2>
              <p className="text-lg text-gray-600">
                Have questions? Our team is here to help. Reach out through any of these channels.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Phone</h3>
                  <p className="text-gray-600">+254 0710546911</p>
                  <p className="text-gray-600">Mon-Fri, 8am-5pm EAT</p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Email</h3>
                  <p className="text-gray-600">info@welandfarm.co.ke</p>
                  <p className="text-gray-600">support@welandfarm.co.ke</p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Office</h3>
                  <p className="text-gray-600">Kenyatta Avenue, Nairobi</p>
                  <p className="text-gray-600">Kenya</p>
                </CardContent>
              </Card>
            </div>
            <div className="mt-16 text-center">
              <div className="flex justify-center space-x-6">
                <a href="#" className="text-gray-600 hover:text-green-600">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
                <a href="#" className="text-gray-600 hover:text-green-600">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-gray-600 hover:text-green-600">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427\
                      a4.902 4.902 0 011.153-1.772 4.902 4.902 0 011.772-1.153c.636-.247 1.363-.416 2.427-.465C8.908 2.013 9.252 2 11.685 2h.63z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-orange-50 via-green-50 to-blue-50 border-t py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-green-600" />
            <span className="text-xl font-bold">Weland Farm Assistant</span>
          </div>
          <ul className="flex items-center gap-4 text-sm">
            <li>
              <a href="#" className="text-gray-500 hover:text-green-600">
                Terms of Service
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-500 hover:text-green-600">
                Privacy Policy
              </a>
            </li>
          </ul>
          <ul className="flex items-center gap-4 text-sm">
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-green-500" />
              <span className="text-gray-400">+254 0710546911</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-green-500" />
              <span className="text-gray-400">info@welandfarm.co.ke</span>
            </li>
          </ul>
        </div>
      </footer>
    </div>
  )
}

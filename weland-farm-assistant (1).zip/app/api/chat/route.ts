import type { NextRequest } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { Configuration, OpenAIApi } from "openai"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""
const supabase = createClient(supabaseUrl, supabaseServiceKey)

// Initialize OpenAI
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(configuration)

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()
    const lastMessage = messages[messages.length - 1].content

    // Generate embedding for the query
    const embeddingResponse = await openai.createEmbedding({
      model: "text-embedding-ada-002",
      input: lastMessage,
    })

    const [{ embedding }] = embeddingResponse.data.data

    // Search for similar documents in Supabase
    const { data: documents, error } = await supabase.rpc("match_documents", {
      query_embedding: embedding,
      match_threshold: 0.5,
      match_count: 3,
    })

    if (error) {
      console.error("Error searching for documents:", error)
      throw error
    }

    // Format context from retrieved documents
    const context = documents.map((doc: any) => doc.content).join("\n\n")

    // Generate response using OpenAI
    const chatResponse = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are Weland Chat, an agricultural assistant for Weland Farm Assistant in Kenya.
          You provide advice on soil management, crop selection, and farming practices.
          Use the following information to answer the user's question:
          ${context}
          
          If you don't know the answer based on the provided information, say so politely and suggest contacting Weland Farm Assistant directly.
          Always be helpful, concise, and focused on Kenyan agriculture.`,
        },
        { role: "user", content: lastMessage },
      ],
    })

    const responseText = chatResponse.data.choices[0].message?.content || "I'm sorry, I couldn't generate a response."

    return Response.json({ response: responseText })
  } catch (error) {
    console.error("Error in chat API:", error)
    return Response.json({ error: "An error occurred while processing your request" }, { status: 500 })
  }
}

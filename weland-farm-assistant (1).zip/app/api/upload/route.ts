import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { Configuration, OpenAIApi } from "openai"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""
const supabase = createClient(supabaseUrl, supabaseServiceKey)

// Initialize OpenAI
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(configuration)

// Simple text splitter function
function splitTextIntoChunks(text: string, chunkSize = 1000, overlap = 200) {
  const chunks = []
  let i = 0
  while (i < text.length) {
    // If this isn't the first chunk, include overlap from the previous chunk
    const start = i === 0 ? 0 : i - overlap
    const end = Math.min(start + chunkSize, text.length)
    chunks.push(text.slice(start, end))
    i = end
  }
  return chunks
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Extract text from the file
    const text = await file.text()

    // Split the text into chunks
    const textChunks = splitTextIntoChunks(text)

    // Process each chunk
    for (const chunk of textChunks) {
      // Generate embedding using OpenAI
      const embeddingResponse = await openai.createEmbedding({
        model: "text-embedding-ada-002",
        input: chunk,
      })

      const [{ embedding }] = embeddingResponse.data.data

      // Store in Supabase
      await supabase.from("documents").insert({
        content: chunk,
        metadata: { source: file.name },
        embedding,
      })
    }

    return NextResponse.json({ success: true, documentCount: textChunks.length })
  } catch (error) {
    console.error("Error processing file:", error)
    return NextResponse.json({ error: "Failed to process file" }, { status: 500 })
  }
}
